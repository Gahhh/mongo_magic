database_url = "mongodb+srv://sam:sam@cluster0.ubskf.mongodb.net/?retryWrites=true&w=majority"

def get_db_url():
    return database_url